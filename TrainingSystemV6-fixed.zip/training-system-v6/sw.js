/* ASCENSUS SW 9.1.8 */
const CACHE = 'ascensus-shell-918';
const SHELL = [
  './index.html',
  './manifest.webmanifest',
  './icon-192.png',
  './icon-512.png',
  './apple-touch-icon.png'
];
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE).then(c => c.addAll(SHELL).catch(() => {})).then(() => self.skipWaiting())
  );
});
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});
self.addEventListener('fetch', event => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  const same = url.origin === self.location.origin;
  if (!same) return;
  const isNav = req.mode === 'navigate' ||
    (req.headers.get('accept') || '').includes('text/html') ||
    /index\.html\/?$/.test(url.pathname) ||
    url.pathname.endsWith('/');
  if (isNav) {
    event.respondWith(
      fetch(req).then(res => {
        const copy = res.clone();
        caches.open(CACHE).then(c => {
          c.put('./index.html', copy).catch(() => {});
          try { c.put(req, res.clone()); } catch (e) {}
        });
        return res;
      }).catch(() =>
        caches.match('./index.html').then(r => r || caches.match(req))
      )
    );
    return;
  }
  event.respondWith(
    caches.match(req).then(hit => {
      if (hit) return hit;
      return fetch(req).then(res => {
        if (res && res.ok) {
          const copy = res.clone();
          caches.open(CACHE).then(c => c.put(req, copy)).catch(() => {});
        }
        return res;
      }).catch(() => caches.match('./index.html'));
    })
  );
});
