ASCENSUS: SYSTEM
Открой index.html в браузере (лучше через локальный сервер).
Сборка APK — см. BUILD-APK.txt
